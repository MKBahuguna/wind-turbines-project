raw_table_name = 'dmfos_trial.raw.data_group_1'
cleaned_table_name = 'dmfos_trial.raw.cleaned'
statistics_table_name = 'dmfos_trial.raw.statistics'
anomalies_table_name = 'dmfos_trial.raw.anomalies'