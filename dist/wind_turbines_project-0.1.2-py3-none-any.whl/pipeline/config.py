database_name = "dmfos_trial"
schema_name = "turbines"

raw_data_path = "/Workspace/Shared/data/*.csv"
cleaned_table_name = 'cleaned'
statistics_table_name = 'statistics'
anomalies_table_name = 'anomalies'
